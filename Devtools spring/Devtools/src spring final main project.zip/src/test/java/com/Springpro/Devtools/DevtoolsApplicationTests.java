package com.Springpro.Devtools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevtoolsApplicationTests {

	@Test
	void contextLoads() {
	}

}
