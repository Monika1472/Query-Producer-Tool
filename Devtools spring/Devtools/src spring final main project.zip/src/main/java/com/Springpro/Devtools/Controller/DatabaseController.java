package com.Springpro.Devtools.Controller;
import com.Springpro.Devtools.Entity.Database;
import com.Springpro.Devtools.Service.DatabaseService;
import com.Springpro.Devtools.Service.MongoDBService;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.bind.annotation.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@CrossOrigin("*")
@RestController
@RequestMapping("/user")
public class DatabaseController {
    private JdbcTemplate customJdbcTemplate;
    @Autowired
    private DatabaseService databaseService;
    @Autowired
    private MongoDBService mongoDbService;
    @GetMapping("/getCredentials")
    public List<Database> getAllDB(){
        return databaseService.getAllDatabase();
    }
    @GetMapping("/getCredentialbyId/{databaseid}")
    public ResponseEntity<Database> getDBbyId(@PathVariable int databaseid){
        Database credentials= databaseService.getDatabasebyId(databaseid);
        try {
            if ("MySQL".equalsIgnoreCase(credentials.getDatabasetype())) {
                DriverManagerDataSource customDataSource = new DriverManagerDataSource();
                customDataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
                customDataSource.setUrl("jdbc:mysql://" + credentials.getHostname() + ":" + credentials.getPortno() + "/" + credentials.getDbname());
                customDataSource.setUsername(credentials.getUsername());
                customDataSource.setPassword(credentials.getPassword());
                customJdbcTemplate = new JdbcTemplate(customDataSource);
                databaseService.setCustomJdbcTemplate(customJdbcTemplate);

                System.out.println(customDataSource.getUrl());
                return ResponseEntity.ok(credentials);
            } else if ("MongoDB".equalsIgnoreCase(credentials.getDatabasetype())) {
                String encodedUsername = URLEncoder.encode(credentials.getUsername(), StandardCharsets.UTF_8.toString());
                String encodedPassword = URLEncoder.encode(credentials.getPassword(), StandardCharsets.UTF_8.toString());
                String connectionStringStr = String.format(
                        "mongodb+srv://%s:%s@%s/%s",
                        encodedUsername,
                        encodedPassword,
                        credentials.getHostname(),
                        credentials.getDbname()
                );
                System.out.println(connectionStringStr);
                mongoDbService.setCustomMongoConnectionString(connectionStringStr);
                mongoDbService.setCustomMongoDBName(credentials.getDbname());
                MongoClient mongoClient = MongoClients.create(connectionStringStr);
                mongoClient.close();
                return ResponseEntity.ok(credentials);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.ok(credentials);
    }
    @PostMapping("/connect")
    public ResponseEntity<String> connectToDatabase(@RequestBody Database credentials) {
        try {
            if ("MySQL".equalsIgnoreCase(credentials.getDatabasetype())) {
                DriverManagerDataSource customDataSource = new DriverManagerDataSource();
                customDataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
                customDataSource.setUrl("jdbc:mysql://" + credentials.getHostname() + ":" + credentials.getPortno() + "/" + credentials.getDbname());
                customDataSource.setUsername(credentials.getUsername());
                customDataSource.setPassword(credentials.getPassword());
                customJdbcTemplate = new JdbcTemplate(customDataSource);
                databaseService.setCustomJdbcTemplate(customJdbcTemplate);
                databaseService.saveDatabase(credentials);

                System.out.println(customDataSource.getUrl());
                return ResponseEntity.ok("Connected to MySQL successfully!");
            } else if ("MongoDB".equalsIgnoreCase(credentials.getDatabasetype())) {
                String encodedUsername = URLEncoder.encode(credentials.getUsername(), StandardCharsets.UTF_8.toString());
                String encodedPassword = URLEncoder.encode(credentials.getPassword(), StandardCharsets.UTF_8.toString());
                String connectionStringStr = String.format(
                        "mongodb+srv://%s:%s@%s/%s",
                        encodedUsername,
                        encodedPassword,
                        credentials.getHostname(),
                        credentials.getDbname()
                );
                System.out.println(connectionStringStr);
                mongoDbService.setCustomMongoConnectionString(connectionStringStr);
                mongoDbService.setCustomMongoDBName(credentials.getDbname());
                databaseService.saveDatabase(credentials);
                MongoClient mongoClient = MongoClients.create(connectionStringStr);
                mongoClient.close();
                return ResponseEntity.ok("Connected to MongoDB successfully");
            } else {
                System.out.println(credentials.getDatabasetype());
                return ResponseEntity.badRequest().body("Error! Invalid database type provided");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("Connection failed. " + e.getMessage());
        }
    }


    @GetMapping("/sql/Queries/executeQuery/{query}")
    public List<Map<String, Object>> executeQuery(@PathVariable String query) {
        if (customJdbcTemplate == null) {
            return (List<Map<String, Object>>) ResponseEntity.badRequest().body("JdbcTemplate is not initialized.");
        }
        return customJdbcTemplate.queryForList(query);
    }

    @GetMapping("/mongo/getCollections")
    public ResponseEntity<List<String>> getCollections() {
        System.out.println(mongoDbService.getCustomMongoConnectionString());
        MongoClient mongoClient = MongoClients.create(mongoDbService.getCustomMongoConnectionString());
        try {
            MongoDatabase database = mongoClient.getDatabase(mongoDbService.getCustomMongoDBName());
            List<String> collections = new ArrayList<>();
            for (String collectionName : database.listCollectionNames()) {
                collections.add(collectionName);
            }
            return ResponseEntity.ok(collections);
        } finally {
            mongoClient.close();
        }
    }

    @GetMapping("/mongo/collections/getDocuments/{collectionName}")
    public ResponseEntity<List<String>> getDocuments(@PathVariable String collectionName) {
        System.out.println(mongoDbService.getCustomMongoConnectionString());
        MongoClient mongoClient = MongoClients.create(mongoDbService.getCustomMongoConnectionString());
        try {
            MongoDatabase database = mongoClient.getDatabase(mongoDbService.getCustomMongoDBName());
            MongoCollection<Document> collection = database.getCollection(collectionName);
            List<String> details = new ArrayList<>();
            for (Document document : collection.find()) {
                details.add(document.toJson());
            }
            return ResponseEntity.ok(details);
        }finally {
            mongoClient.close();
        }
    }

    @GetMapping("/mongo/executeQuery/{collectionName}/{query}")
    public ResponseEntity<List<String>> executeQuery(@PathVariable String collectionName, @PathVariable String query) {
        try {
            System.out.println(query);
            System.out.println(mongoDbService.getCustomMongoConnectionString());
            MongoClient mongoClient = MongoClients.create(mongoDbService.getCustomMongoConnectionString());
            try {
                MongoDatabase database = mongoClient.getDatabase(mongoDbService.getCustomMongoDBName());
                MongoCollection<Document> collection = database.getCollection(collectionName);
                List<String> results = new ArrayList<>();
                for (Document document : collection.find(Document.parse(query))) {
                    results.add(document.toJson());
                }
                System.out.println(Document.parse(query));
                return ResponseEntity.ok(results);
            } finally {
                mongoClient.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body(Collections.singletonList("Error executing MongoDB query"));
        }
    }
}

