package com.Springpro.Devtools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevtoolsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevtoolsApplication.class, args);
	}

}
